import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import * as schema from "@shared/schema";
import path from "path";

// Use database.db in the project root
const dbPath = path.join(process.cwd(), "database.db");

// Initialize SQLite database
const sqlite = new Database(dbPath);

// Initialize Drizzle with the schema
export const db = drizzle(sqlite, { schema });
